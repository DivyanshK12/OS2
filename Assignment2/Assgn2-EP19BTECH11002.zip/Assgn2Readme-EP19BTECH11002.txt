For PThreads :
g++ Assgn2SrcpthreadEP19BTECH11002.cpp -lpthread -o main
./main

For OpenMP :
g++ Assgn2SrcOpenMpEP19BTECH11002.cpp -fopenmp -o main
./main

Note that both codes read from input.txt and write to output.txt